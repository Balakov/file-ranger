# file-ranger
A dual-pane file explorer for Windows
